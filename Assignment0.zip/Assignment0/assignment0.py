import json
from itertools import islice

def add_values(user_dict, key, values) :   #made to make adding values easy
    if key not in user_dict :
        user_dict[key] = list()
    user_dict[key].extend(values)
    return user_dict

#Start global variables
user_dict = []
i = 1

with open('user_dict.txt') as t:
    new_dict = json.load(t)
text_file = open('user_dict.txt', 'r')
lines = text_file.read().rstrip()
#print(lines)
username = input('Enter your first and last name: ')

if username in lines:
    print("You have an account")
else:
    print('You are making a new account. Please follow the following directions')
    while i < 6:
        movie = input('Input title of your favorite movie: ')
        director = input('Input title of the director: ')
        year = input('Input the year it was released: ')
        IMDB = input('Input the IMDB star rating: ')
        rotten = input('Input the Rotten Tomatoes rating: ')
        MPAA = input('Input the MPAA rating: ')
        favorite = i
        new_dict.append({"name": username, "Title": movie, "Director": director, "Year": year, "IMDB rating": IMDB, "Rotten Tomatoes": rotten, "Age Rating": MPAA, "Your Rating": favorite})
        i = i + 1
#print(new_dict)
    with open('user_dict.txt', 'w') as f:
        json.dump(new_dict, f, indent=4, separators=(',', ': '))

with open('user_dict.txt', 'r') as filedata:
   for line in filedata:
       if username in line:
           print(list(islice(filedata, 7))[0:7])

       else:
           continue
